class Main {
    public static void main(String args) {
        System.out.println("Hello, welcome to the java world");
    }
}
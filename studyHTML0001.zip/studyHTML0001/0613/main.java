class main {
    public static void main(String[] as) {
        System.out.println("asd");
    }
}

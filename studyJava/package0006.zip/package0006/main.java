import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import package0006.*;

public class main {
    public static void main(String[] args) {
        SmartTelevision tv = new SmartTelevision();
		RemoteControl.changeBattery();

        Audio audio = new Audio();

        audio.turnOn();
        audio.turnOff();
        audio.setVolume(10);

        System.out.println("Start");
        tv.setMute(true);
        tv.setChannel(80);

        Scanner scan = new Scanner(System.in);

        System.out.println("채널을 입력하세요.");
        System.out.println("ex) 20 30 45 70 120");
        System.out.print(">> ");

        String str = scan.nextLine();
        String[] Channel = str.split("\\s+");
        
        Kim kim = new Kim();
        Lee lee = new Lee();
        Park park = new Park();

        int a = 0;
        int b = 0;
        int c = 0;
        int i = 0;

        while (true) {
            i++;
            System.out.print(i + " ");

            if (i % 3 == 0) {
                park.changeChannel(Channel, a);
                a++;

                if (i % 5 == 0) {
                    kim.changeChannel(Channel, b);
                    b++;
                }

                if (i % 11 == 0) {
                    lee.changeChannel(Channel, c);
                    c++;
                }
            }
            
            else if (i % 5 == 0) {
                kim.changeChannel(Channel, b);
                b++;
            }
            
            else if (i % 11 == 0) {
                lee.changeChannel(Channel, c);
                c++;
            }

            else {
                try {
                    TimeUnit.SECONDS.sleep(1);
                    System.out.println("시간이 가는 중...");

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

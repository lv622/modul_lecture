package package0004_gameSlimeLand.slime;

public class actionSlimeBludslime extends actionSlime {

    @Override
    public void playAction() {
        System.out.println("푸른 슬라임이 행동합니다");
    }
    
}

package package0004_gameSlimeLand.slime;

public class actionSlimeRedslime extends actionSlime{

    @Override
    public void playAction() {
        System.out.println("붉은 슬라임이 행동합니다");
    }
    
}
